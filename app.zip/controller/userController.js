
import bcrypt from "bcrypt"
import userModel from "../model/userModel.js"
const userRegister=async(req,res)=>{
    const user = req.body;
    console.log(user)
    user.password= bcrypt.hashSync(user.password,10)
    const dbUser=await userModel.create(user)
    dbUser.passsword="XXX"
    return res.status(201).json({
      message: "User registered successfully", dbUser
    })
}


export {userRegister}